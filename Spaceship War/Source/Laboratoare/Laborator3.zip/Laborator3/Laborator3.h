#pragma once

#include <Component/SimpleScene.h>
#include <string>
#include <Core/Engine.h>

class Laborator3 : public SimpleScene
{
	public:
		Laborator3();
		~Laborator3();

		void Init() override;

	private:
		void FrameStart() override;
		void Update(float deltaTimeSeconds) override;
		void FrameEnd() override;

		void OnInputUpdate(float deltaTime, int mods) override;
		void OnKeyPress(int key, int mods) override;
		void OnKeyRelease(int key, int mods) override;
		void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
		void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;

	protected:
		glm::mat3 modelMatrix;
		float translateX, translateY;
		float scaleX, scaleY;
		float angularStep;
		//
		int		square1_dCounter;
		bool	square1_down;
		float	square1_speed;
		float	square1_Y;
		//
		int		square2_sCounter;
		float	initialScale;
		float	square2_scale;
		float	square2_speed;
		bool	square2_growing;
		//
		float	square3_angle;
		float	square3_transl;
		bool	square3_moveIt;

		float cx, cy;
		//
		float square2_initialX;
		float square2_initialY;

		float dx, dy;
		float square1_X;

		bool s1_up, s1_right;
		float square1_angle;

		
};
