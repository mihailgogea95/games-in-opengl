#include "Laborator3.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

Laborator3::Laborator3()
{
}

Laborator3::~Laborator3()
{
}

void Laborator3::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	cameraInput->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 100;

	// compute coordinates of square center
	cx = corner.x + squareSide / 2;
	cy = corner.y + squareSide / 2;
	
	// initialize tx and ty (the translation steps)
	translateX = 0;
	translateY = 0;

	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;
	
	// initialize angularStep
	angularStep = 0;
	

	Mesh* square1 = Object2D::CreateSquare("square1", corner, squareSide, glm::vec3(1, 0, 0), true);
	AddMeshToList(square1);
	
	Mesh* square2 = Object2D::CreateSquare("square2", corner, squareSide, glm::vec3(0, 1, 0));
	AddMeshToList(square2);

	Mesh* square3 = Object2D::CreateSquare("square3", corner, squareSide, glm::vec3(0, 0, 1));
	AddMeshToList(square3);

	//
	square1_speed	= 100;
	square1_Y		= 0;
	square2_scale	= 1;
	square2_speed	= .5f;
	square2_growing = true;
}

void Laborator3::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator3::Update(float deltaTimeSeconds)
{
	// TODO: update steps for translation, rotation, scale, in order to create animations
	
	modelMatrix = glm::mat3(1);

	/*if (square1_down) {
		square1_Y -= square1_speed * deltaTimeSeconds;
	}
	else {
		square1_Y += square1_speed * deltaTimeSeconds;
	}
	square1_dCounter++;
	*/
	//modelMatrix *= Transform2D::Translate(150, square1_Y);
	// TODO: create animations by multiplying current transform matrix with matrices from Transform 2D

	

	/*if (square1_dCounter == square1_speed) {
		square1_dCounter = -square1_speed;
		square1_down = !square1_down;
	}*/
	//modelMatrix = glm::mat3()

	modelMatrix *= Transform2D::Translate(400, 250);
	square1_angle += 2 * deltaTimeSeconds;
	//square3_transl += 100 * square3_angle;
	if (square1_angle >= 360) {
		square1_angle -= 360;
		//square3_moveIt = !square3_moveIt;
	}
	modelMatrix *= Transform2D::Translate(cx, cy);
	modelMatrix *= Transform2D::Rotate(square1_angle);
	//modelMatrix *= Transform2D::Translate(-cx, -cy);
	modelMatrix *= Transform2D::Translate(150,150);
	modelMatrix *= Transform2D::Translate(-cx, -cy);



	RenderMesh2D(meshes["square1"], shaders["VertexColor"], modelMatrix);

	square3_angle += 5 * deltaTimeSeconds;
	//square3_transl += 100 * square3_angle;
	if (square3_angle >= 360) {
		square3_angle -= 360;
		//square3_moveIt = !square3_moveIt;
	}
	modelMatrix *= Transform2D::Translate(cx, cy);
	modelMatrix *= Transform2D::Rotate(square3_angle);
	modelMatrix *= Transform2D::Translate(100, 100);	
	modelMatrix *= Transform2D::Translate(-cx, -cy);
	RenderMesh2D(meshes["square3"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(400, 250);
	if (square2_growing) {
		square2_scale += square2_speed * deltaTimeSeconds;
	}
	else {
		square2_scale -= square2_speed * deltaTimeSeconds;
	}
	square2_sCounter++;
	
	modelMatrix *= Transform2D::Translate(cx, cy);
	modelMatrix *= Transform2D::Scale(square2_scale, square2_scale);
	modelMatrix *= Transform2D::Translate(-cx, -cy);
	//TODO create animations by multiplying current transform matrix with matrices from Transform 2D
	if (square2_scale >= 2) {
		//square2_sCounter = -square2_speed;
		square2_growing = !square2_growing;
	}
	else if (square2_scale <= 1) {
		square2_growing = !square2_growing;
	}
	//modelMatrix *= Transform2D::Translate(-800*square2_scale*deltaTimeSeconds, -500*square2_scale*deltaTimeSeconds);
	RenderMesh2D(meshes["square2"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	



	/*modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(650, 250);
	
	*/
	//TODO create animations by multiplying current transform matrix with matrices from Transform 2D
	//RenderMesh2D(meshes["square3"], shaders["VertexColor"], modelMatrix);
}

void Laborator3::FrameEnd()
{

}

void Laborator3::OnInputUpdate(float deltaTime, int mods)
{
	
}

void Laborator3::OnKeyPress(int key, int mods)
{
	// add key press event
};

void Laborator3::OnKeyRelease(int key, int mods)
{
	// add key release event
};

void Laborator3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
};

void Laborator3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
};

void Laborator3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}